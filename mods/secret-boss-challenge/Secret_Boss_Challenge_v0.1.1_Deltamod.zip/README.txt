Secret Boss Challenge v0.1.1

Install this ZIP directly through Deltamod.

This release fixes v0.1.0's modding.xml entries. The patch files are UTMT CSX scripts and are now correctly declared with type="csx" instead of type="xdelta".

Do not install v0.1.0 alongside this release. Remove or update the old version first.
