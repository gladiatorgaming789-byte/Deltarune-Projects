Secret Boss Challenge v0.4.0

Install this ZIP directly through Deltamod. Keep the archive intact.
The package ID is unchanged, so v0.4.0 updates the existing Secret Boss Challenge installation.

CHAPTERS 1 AND 2
- Keeps the optional Boss Challenge setting, harder secret bosses, and dual secret-boss rewards.

CHAPTER 5: PINK REWARD RULES
- Boss Challenge can be toggled from Chapter 5's CONFIG menu.
- Defeating Pink with Boss Challenge OFF keeps the vanilla Pink rewards and vanilla three-flower shop limit.
- Defeating Pink with Boss Challenge ON awards Pink Scarf, 3 additional Pink Coins, and a fourth regular flower purchase.
- Defeating Pink with Meaner Bombs selected AND Boss Challenge ON also awards Pink's Staff.
- Reward eligibility is recorded when Pink is defeated; enabling Boss Challenge afterward does not qualify the clear.

PINK SCARF
- Ralsei weapon: 8 AT, 4 DF, and 12 MAG.
- Unlocks the new Shield spell while equipped.
- Shield costs 65% TP and targets one party member.
- Shield reduces damage to the selected party member by about 75% through the next enemy attack phase.
- Recasting Shield replaces the previous protected target.
- Passively increases graze hitbox size and graze TP gain by about 10% while its wearer is in the active party.

PINK'S STAFF
- Kris weapon: 14 AT, 2 DF, and 4 MAG.
- Requires a Meaner Bombs victory with Boss Challenge ON.

SAVE AND INVENTORY HANDLING
- Weapon ID 38 remains Pink Scarf, preserving the v0.2.x item-slot migration.
- If WEAPON storage is full, eligible equipment remains pending and the flower shop retries later.
- Coin and equipment grants use separate one-time save states.
- Older completed clears with no saved proof that Boss Challenge was active are treated as non-challenge clears.

COMPATIBILITY
- Uses source-anchor CSX patches for Deltamod merge support.
- Chapter 5 was tested with Debug Mode v4.01 in both patch orders.
- Applying the Chapter 5 script twice produces a byte-identical data.win.
- A mod changing the same CONFIG, Pink reward, weapon table, spell, damage, graze, or flower-shop anchors may require a dedicated merged version.

Target: DELTARUNE Windows full release, launcher version v23.
