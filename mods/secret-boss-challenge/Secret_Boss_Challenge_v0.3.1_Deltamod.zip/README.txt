Secret Boss Challenge v0.3.1

Install this ZIP directly through Deltamod. Keep the archive intact.
The package ID is unchanged, so v0.3.1 updates the existing Secret Boss Challenge installation.

CHAPTERS 1 AND 2
- Keeps the optional Boss Challenge setting, harder secret bosses, and dual secret-boss rewards.

CHAPTER 5: PINK REWARD RULES
- Boss Challenge can be toggled from Chapter 5's CONFIG menu.
- Defeating Pink with Boss Challenge OFF keeps the vanilla Pink rewards and vanilla three-flower shop limit.
- Defeating Pink with Boss Challenge ON awards Pink Scarf, a Ralsei weapon with 8 AT, 4 DF, and 12 MAG.
- The same challenge clear awards 3 additional Pink Coins once per save.
- The challenge clear permits four regular flower purchases instead of three.
- Defeating Pink with Meaner Bombs selected AND Boss Challenge ON also awards Pink's Staff.
- Pink's Staff is a Kris weapon with 14 AT, 2 DF, and 4 MAG.
- Reward eligibility is recorded when Pink is defeated; enabling Boss Challenge afterward does not qualify the clear.
- Flowery's special scarf remains available after the regular flower choices.

SAVE AND INVENTORY HANDLING
- Weapon ID 38 remains Pink Scarf, preserving the v0.2.x item-slot migration.
- If WEAPON storage is full, eligible equipment remains pending and the flower shop retries later.
- Coin and equipment grants use separate one-time save states.
- Older completed clears with no saved proof that Boss Challenge was active are treated as non-challenge clears; this prevents enabling the option later from granting rewards retroactively.

COMPATIBILITY
- Uses source-anchor CSX patches for Deltamod merge support.
- Chapter 5 was tested with Debug Mode v4.01 in both patch orders.
- Applying the Chapter 5 script twice produces a byte-identical data.win.
- A mod changing the same CONFIG, Pink reward, weapon table, or flower-shop anchors may require a dedicated merged version.

Target: DELTARUNE Windows full release, launcher version v23.
