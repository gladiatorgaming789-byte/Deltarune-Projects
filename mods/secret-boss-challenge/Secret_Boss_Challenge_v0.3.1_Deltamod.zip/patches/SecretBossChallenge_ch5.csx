using System;
using UndertaleModLib.Models;
using UndertaleModLib.Compiler;

EnsureDataLoaded();

UndertaleModLib.Compiler.CodeImportGroup importGroup = new(Data, null, Data.ToolInfo.DecompilerSettings)
{
    ThrowOnNoOpFindReplace = true,
    MainThreadAction = MainThreadAction
};

int CountOccurrences(string source, string value)
{
    if (String.IsNullOrEmpty(value))
        return 0;
    int count = 0;
    int index = 0;
    while ((index = source.IndexOf(value, index, StringComparison.Ordinal)) >= 0)
    {
        count++;
        index += value.Length;
    }
    return count;
}

bool HasPatchMarker(string source, string label)
{
    if (label.Contains("setting load")) return source.Contains("global.secret_boss_challenge = ini_read_real");
    if (label.Contains("row count")) return source.Contains("global.submenucoord[30] > 7");
    if (label.Contains("toggle action")) return source.Contains("ini_write_real(\"MODS\", \"SECRET_BOSS_CHALLENGE\"");
    if (label.Contains("shifted actions")) return source.Contains("global.submenucoord[30] == 7");
    if (label.Contains("toggle text")) return source.Contains("challengeoff = \"OFF\"");
    if (label.Contains("cursor layout")) return source.Contains("_configHeartY");
    if (label.Contains("console rows") || label.Contains("desktop rows")) return source.Contains("\"Boss Challenge\"");
    if (label.Contains("Pink reward definitions")) return source.Contains("secret_boss_challenge_pink_scarf_name") && source.Contains("secret_boss_challenge_pinks_staff_name");
    if (label.Contains("reward state")) return source.Contains("pink_scarf_awarded_now") && source.Contains("global.flag[2493]") && source.Contains("pink_staff_awarded_now");
    if (label.Contains("reward message")) return source.Contains("Meaner Bombs clear!");
    if (label.Contains("retroactive reward")) return source.Contains("regularpurchasegoal = 3") && source.Contains("global.flag[2493]") && source.Contains("scr_weaponcheck_inventory(39)");
    if (label.Contains("completed purchase count")) return source.Contains("purchasecount == totalpurchasegoal");
    if (label.Contains("choice count dialogue")) return source.Contains("regularpurchasegoal == 4") && source.Contains("choose 4 of us!");
    if (label.Contains("Flowery price threshold")) return source.Contains("purchasecount == regularpurchasegoal");
    if (label.Contains("final podium removal threshold")) return source.Contains("purchasecount == totalpurchasegoal");
    if (label.Contains("progression thresholds")) return source.Contains("else if (purchasecount == totalpurchasegoal)");
    return false;
}

string ReplaceExact(string source, string oldText, string newText, string label)
{
    // These patched blocks intentionally retain their vanilla line as one branch
    // or prefix. Check their unique marker before counting the old anchor so a
    // second application cannot nest the patch inside itself.
    if ((label.Contains("reward message") || label.Contains("choice count dialogue")) && HasPatchMarker(source, label))
        return source;

    int oldCount = CountOccurrences(source, oldText);
    if (oldCount == 1)
        return source.Replace(oldText, newText, StringComparison.Ordinal);

    // Permit a second run without duplicating the patch, including after
    // UndertaleModTool normalizes whitespace and comments during decompilation.
    if (oldCount == 0 && (CountOccurrences(source, newText) == 1 || HasPatchMarker(source, label)))
        return source;

    throw new Exception($"Secret Boss Challenge: {label} expected one source match, found {oldCount}. The game version or another mod changed the same code.");
}

void PatchCode(string codeName, (string OldText, string NewText, string Label)[] replacements)
{
    UndertaleCode code = Data.Code.ByName(codeName);
    if (code is null)
        throw new Exception($"Secret Boss Challenge: missing code entry {codeName}.");

    string source = GetDecompiledText(code);
    string patched = source;
    foreach (var replacement in replacements)
        patched = ReplaceExact(patched, replacement.OldText, replacement.NewText, replacement.Label);

    if (!String.Equals(source, patched, StringComparison.Ordinal))
        importGroup.QueueReplace(code, patched);
}

if (Data.Code.ByName("gml_Object_obj_pink_enemy_Create_0") is null)
    throw new Exception("Secret Boss Challenge: this patch targets DELTARUNE Chapter 5.");

PatchCode("gml_Object_obj_darkcontroller_Create_0", new[]
{
    (@"mmy[1] = 0;
mmy[2] = 0;
mmy[3] = 0;
global.submenu = 0;
global.charselect = -1;
for (var i = 0; i < 36; i += 1)
{
    global.submenucoord[i] = 0;
", @"mmy[1] = 0;
mmy[2] = 0;
mmy[3] = 0;
global.submenu = 0;
if (!variable_global_exists(""secret_boss_challenge""))
{
    ossafe_ini_open(""true_config.ini"");
    global.secret_boss_challenge = ini_read_real(""MODS"", ""SECRET_BOSS_CHALLENGE"", 0);
    ossafe_ini_close();
}
global.charselect = -1;
for (var i = 0; i < 36; i += 1)
{
    global.submenucoord[i] = 0;
", "ch5/gml_Object_obj_darkcontroller_Create_0 setting load"),
});

PatchCode("gml_Object_obj_darkcontroller_Step_0", new[]
{
    (@"            if (down_p())
            {
                movenoise = 1;
                global.submenucoord[30] += 1;
                if (global.submenucoord[30] > 6)
                {
                    global.submenucoord[30] = 6;
                }
            }
", @"            if (down_p())
            {
                movenoise = 1;
                global.submenucoord[30] += 1;
                if (global.submenucoord[30] > 7)
                {
                    global.submenucoord[30] = 7;
                }
            }
", "ch5/gml_Object_obj_darkcontroller_Step_0 row count"),
    (@"                        if (__menuOpt == 1)
                        {
                            global.flag[25] = !global.flag[25];
                            show_debug_message_concat(""global.flag[25]="", global.flag[25]);
                        }
                    }
                }
                if (global.is_console)
", @"                        if (__menuOpt == 1)
                        {
                            global.flag[25] = !global.flag[25];
                            show_debug_message_concat(""global.flag[25]="", global.flag[25]);
                        }
                    }
                }
                if (global.submenucoord[30] == 5)
                {
                    global.secret_boss_challenge = 1 - global.secret_boss_challenge;
                    ossafe_ini_open(""true_config.ini"");
                    ini_write_real(""MODS"", ""SECRET_BOSS_CHALLENGE"", global.secret_boss_challenge);
                    ossafe_ini_close();
                }
                if (global.is_console)
", "ch5/gml_Object_obj_darkcontroller_Step_0 toggle action"),
    (@"                if (global.is_console)
                {
                    if (global.submenucoord[30] == 3)
                    {
                        if (global.chapter == 5 && global.tempflag[52] == 1)
                        {
                            global.flag[1392] = !global.flag[1392];
                        }
                        else
                        {
                            global.flag[11] = !global.flag[11];
                        }
                    }
                    if (global.submenucoord[30] == 4)
                    {
                        if (global.disable_border)
                        {
                            selectnoise = 0;
                        }
                        else
                        {
                            global.submenu = 36;
                            check_border = 1;
                            border_select = 0;
                        }
                    }
                    if (global.submenucoord[30] == 5)
                    {
                        global.submenu = 34;
                    }
                    if (global.submenucoord[30] == 6)
                    {
                        m_quit = 1;
                        cancelnoise = 1;
                    }
                }
                else
                {
                    if (global.submenucoord[30] == 3)
                    {
                        with (obj_time)
                        {
                            fullscreen_toggle = 1;
                        }
                    }
                    if (global.submenucoord[30] == 4)
                    {
                        if (global.chapter == 5 && global.tempflag[52] == 1)
                        {
                            global.flag[1392] = !global.flag[1392];
                        }
                        else
                        {
                            global.flag[11] = !global.flag[11];
                        }
                    }
                    if (global.submenucoord[30] == 5)
                    {
                        global.submenu = 34;
                    }
                    if (global.submenucoord[30] == 6)
                    {
                        m_quit = 1;
                        cancelnoise = 1;
                    }
                }
", @"                if (global.is_console)
                {
                    if (global.submenucoord[30] == 3)
                    {
                        if (global.chapter == 5 && global.tempflag[52] == 1)
                        {
                            global.flag[1392] = !global.flag[1392];
                        }
                        else
                        {
                            global.flag[11] = !global.flag[11];
                        }
                    }
                    if (global.submenucoord[30] == 4)
                    {
                        if (global.disable_border)
                        {
                            selectnoise = 0;
                        }
                        else
                        {
                            global.submenu = 36;
                            check_border = 1;
                            border_select = 0;
                        }
                    }
                    if (global.submenucoord[30] == 6)
                    {
                        global.submenu = 34;
                    }
                    if (global.submenucoord[30] == 7)
                    {
                        m_quit = 1;
                        cancelnoise = 1;
                    }
                }
                else
                {
                    if (global.submenucoord[30] == 3)
                    {
                        with (obj_time)
                        {
                            fullscreen_toggle = 1;
                        }
                    }
                    if (global.submenucoord[30] == 4)
                    {
                        if (global.chapter == 5 && global.tempflag[52] == 1)
                        {
                            global.flag[1392] = !global.flag[1392];
                        }
                        else
                        {
                            global.flag[11] = !global.flag[11];
                        }
                    }
                    if (global.submenucoord[30] == 6)
                    {
                        global.submenu = 34;
                    }
                    if (global.submenucoord[30] == 7)
                    {
                        m_quit = 1;
                        cancelnoise = 1;
                    }
                }
", "ch5/gml_Object_obj_darkcontroller_Step_0 shifted actions"),
});

PatchCode("gml_Object_obj_darkcontroller_Draw_0", new[]
{
    (@"        if (global.flag[8] == 1)
        {
            flashoff = stringsetloc(""ON"", ""obj_darkcontroller_slash_Draw_0_gml_83_1"");
        }
        shakeoff = stringsetloc(""OFF"", ""obj_darkcontroller_slash_Draw_0_gml_84_0"");
", @"        if (global.flag[8] == 1)
        {
            flashoff = stringsetloc(""ON"", ""obj_darkcontroller_slash_Draw_0_gml_83_1"");
        }
        challengeoff = ""OFF"";
        if (global.secret_boss_challenge == 1)
        {
            challengeoff = ""ON"";
        }
        shakeoff = stringsetloc(""OFF"", ""obj_darkcontroller_slash_Draw_0_gml_84_0"");
", "ch5/gml_Object_obj_darkcontroller_Draw_0 toggle text"),
    (@"        draw_sprite(spr_heart, 0, _heartXPos, yy + 160 + (global.submenucoord[30] * 35));
", @"        var _configHeartY = yy + 160 + (global.submenucoord[30] * 35);
        if (global.submenucoord[30] >= 5)
        {
            _configHeartY = yy + 335 + ((global.submenucoord[30] - 5) * 25);
        }
        draw_sprite(spr_heart, 0, _heartXPos, _configHeartY);
", "ch5/gml_Object_obj_darkcontroller_Draw_0 cursor layout"),
    (@"            draw_text(_xPos, yy + 290, stringsetloc(""Border"", ""obj_darkcontroller_slash_Draw_0_gml_112_0""));
            draw_text(_selectXPos, yy + 290, border_options[selected_border]);
            draw_set_color(c_white);
            draw_text(_xPos, yy + 325, string_hash_to_newline(stringsetloc(""Return to Title"", ""obj_darkcontroller_slash_Draw_0_gml_95_0"")));
            draw_text(_xPos, yy + 360, string_hash_to_newline(back_text));
", @"            draw_text(_xPos, yy + 290, stringsetloc(""Border"", ""obj_darkcontroller_slash_Draw_0_gml_112_0""));
            draw_text(_selectXPos, yy + 290, border_options[selected_border]);
            draw_set_color(c_white);
            draw_text(_xPos, yy + 325, ""Boss Challenge"");
            draw_text(_selectXPos, yy + 325, challengeoff);
            draw_text(_xPos, yy + 350, string_hash_to_newline(stringsetloc(""Return to Title"", ""obj_darkcontroller_slash_Draw_0_gml_95_0"")));
            draw_text(_xPos, yy + 375, string_hash_to_newline(back_text));
", "ch5/gml_Object_obj_darkcontroller_Draw_0 console rows"),
    (@"            draw_text(_xPos, yy + 325, string_hash_to_newline(stringsetloc(""Return to Title"", ""obj_darkcontroller_slash_Draw_0_gml_95_0"")));
            draw_text(_xPos, yy + 360, string_hash_to_newline(back_text));
        }
    }
", @"            draw_text(_xPos, yy + 325, ""Boss Challenge"");
            draw_text(_selectXPos, yy + 325, challengeoff);
            draw_text(_xPos, yy + 350, string_hash_to_newline(stringsetloc(""Return to Title"", ""obj_darkcontroller_slash_Draw_0_gml_95_0"")));
            draw_text(_xPos, yy + 375, string_hash_to_newline(back_text));
        }
    }
", "ch5/gml_Object_obj_darkcontroller_Draw_0 desktop rows"),
});

// Weapon IDs 38 and 39 are unused in the supplied Chapter 5 build.
// v0.2.0 used ID 38 for Pink's Staff; retaining the slot for Pink Scarf
// migrates existing inventories without deleting the reward.
PatchCode("gml_GlobalScript_scr_weaponinfo", new[]
{
    (@"            weaponabilitytemp = """";
            value = 1000;
            break;
        case 50:
            weaponnametemp = stringsetloc(""JingleBlade"", ""scr_weaponinfo_slash_scr_weaponinfo_gml_629_0"");
", @"            weaponabilitytemp = """";
            value = 1000;
            break;
        case 38:
            weaponnametemp = stringsetloc(""Pink Scarf"", ""secret_boss_challenge_pink_scarf_name"");
            weapondesctemp = stringsetloc(""A soft scarf left by Pink.#It glows with bold, affectionate magic."", ""secret_boss_challenge_pink_scarf_desc"");
            wmessage2temp = stringsetloc(""Way too pink. Even for me."", ""secret_boss_challenge_pink_scarf_susie"");
            wmessage3temp = stringsetloc(""It feels warm... and a little dramatic!"", ""secret_boss_challenge_pink_scarf_ralsei"");
            wmessage4temp = stringsetloc(""It's adorable!"", ""secret_boss_challenge_pink_scarf_noelle"");
            weaponattemp = 8;
            weapondftemp = 4;
            weaponmagtemp = 12;
            weaponboltstemp = 1;
            weaponstyletemp = ""?"";
            weapongrazeamttemp = 0;
            weapongrazesizetemp = 0;
            weaponchar1temp = 0;
            weaponchar2temp = 0;
            weaponchar3temp = 1;
            weaponchar4temp = 0;
            weaponicontemp = 3;
            weaponabilityicontemp = 0;
            weaponabilitytemp = """";
            value = 1500;
            break;
        case 39:
            weaponnametemp = stringsetloc(""Pink's Staff"", ""secret_boss_challenge_pinks_staff_name"");
            weapondesctemp = stringsetloc(""A heart-topped staff earned by facing Pink#at her meanest. It hums in Kris's hands."", ""secret_boss_challenge_pinks_staff_desc"");
            wmessage2temp = stringsetloc(""Kris, bonk something with it."", ""secret_boss_challenge_pinks_staff_susie"");
            wmessage3temp = stringsetloc(""It looks like a conductor's baton!"", ""secret_boss_challenge_pinks_staff_ralsei"");
            wmessage4temp = stringsetloc(""That is an extremely pink weapon."", ""secret_boss_challenge_pinks_staff_noelle"");
            weaponattemp = 14;
            weapondftemp = 2;
            weaponmagtemp = 4;
            weaponboltstemp = 1;
            weaponstyletemp = ""?"";
            weapongrazeamttemp = 0;
            weapongrazesizetemp = 0;
            weaponchar1temp = 1;
            weaponchar2temp = 0;
            weaponchar3temp = 0;
            weaponchar4temp = 0;
            weaponicontemp = 1;
            weaponabilityicontemp = 0;
            weaponabilitytemp = """";
            value = 2000;
            break;
        case 50:
            weaponnametemp = stringsetloc(""JingleBlade"", ""scr_weaponinfo_slash_scr_weaponinfo_gml_629_0"");
", "ch5/gml_GlobalScript_scr_weaponinfo Pink reward definitions"),
});

PatchCode("gml_Object_obj_dw_pink_encounter_Step_0", new[]
{
    (@"if (con == 5)
{
    con = 6;
    pinkface.silhouette = false;
", @"if (con == 5)
{
    con = 6;
    if (!variable_global_exists(""secret_boss_challenge""))
    {
        ossafe_ini_open(""true_config.ini"");
        global.secret_boss_challenge = ini_read_real(""MODS"", ""SECRET_BOSS_CHALLENGE"", 0);
        ossafe_ini_close();
    }
    var pink_scarf_awarded_now = false;
    var pink_scarf_pending = false;
    var pink_coins_awarded_now = false;
    var pink_staff_awarded_now = false;
    var pink_staff_pending = false;
    // 0 = unknown, 1 = Pink was defeated with Boss Challenge ON, 2 = ineligible clear.
    if (global.flag[2493] == 0)
    {
        if (global.secret_boss_challenge == 1)
        {
            global.flag[2493] = 1;
        }
        else
        {
            global.flag[2493] = 2;
        }
    }
    if (global.flag[2493] == 1)
    {
        if (global.flag[2490] == 0)
        {
            if (scr_weaponcheck_inventory(38) > 0 || scr_weaponcheck_equipped_any(38) > 0)
            {
                global.flag[2490] = 1;
            }
            else
            {
                scr_weaponget(38);
                if (noroom == 0)
                {
                    global.flag[2490] = 1;
                    pink_scarf_awarded_now = true;
                }
                else
                {
                    pink_scarf_pending = true;
                }
            }
        }
        if (global.flag[2491] == 0)
        {
            global.flag[1312] += 3;
            global.flag[2491] = 1;
            pink_coins_awarded_now = true;
        }
    }
    // 0 = legacy/unknown, 1 = granted, 2 = eligible and pending, 3 = ineligible clear.
    if (global.flag[2492] == 0)
    {
        if (global.flag[2493] == 1 && global.flag[1914] == 2)
        {
            global.flag[2492] = 2;
        }
        else
        {
            global.flag[2492] = 3;
        }
    }
    if (global.flag[2492] == 2)
    {
        if (scr_weaponcheck_inventory(39) > 0 || scr_weaponcheck_equipped_any(39) > 0)
        {
            global.flag[2492] = 1;
        }
        else
        {
            scr_weaponget(39);
            if (noroom == 0)
            {
                global.flag[2492] = 1;
                pink_staff_awarded_now = true;
            }
            else
            {
                pink_staff_pending = true;
            }
        }
    }
    pinkface.silhouette = false;
", "ch5/gml_Object_obj_dw_pink_encounter_Step_0 reward state"),
    (@"    c_snd_play(snd_sparkle_glock);
    c_speaker(""no_name"");
    c_msgsetloc(0, ""* (SHADOWCRYSTAL was added to your KEY ITEMS.)/%"", ""obj_dw_pink_encounter_slash_Step_0_gml_1200_0"");
    c_talk_wait();
    c_var_lerp_to_instance(pk_actor, ""image_index"", 4, 6);
", @"    c_snd_play(snd_sparkle_glock);
    c_speaker(""no_name"");
    c_msgsetloc(0, ""* (SHADOWCRYSTAL was added to your KEY ITEMS.)/%"", ""obj_dw_pink_encounter_slash_Step_0_gml_1200_0"");
    c_talk_wait();
    if (pink_scarf_awarded_now && pink_coins_awarded_now)
    {
        c_snd_play(snd_item);
        c_speaker(""no_name"");
        c_msgset(0, ""* (You got Pink Scarf.)/&* (You got 3 Pink Coins.)/%"");
        c_talk_wait();
    }
    else if (pink_scarf_awarded_now)
    {
        c_snd_play(snd_item);
        c_speaker(""no_name"");
        c_msgset(0, ""* (You got Pink Scarf.)/%"");
        c_talk_wait();
    }
    else if (pink_coins_awarded_now)
    {
        c_snd_play(snd_pink_coin);
        c_speaker(""no_name"");
        c_msgset(0, ""* (You got 3 Pink Coins.)/%"");
        c_talk_wait();
    }
    if (pink_staff_awarded_now)
    {
        c_snd_play(snd_item);
        c_speaker(""no_name"");
        c_msgset(0, ""* (Meaner Bombs clear!)/&* (You got Pink's Staff.)/%"");
        c_talk_wait();
    }
    if (pink_scarf_pending || pink_staff_pending)
    {
        c_speaker(""no_name"");
        if (pink_scarf_pending && pink_staff_pending)
        {
            c_msgset(0, ""* (Your WEAPON storage is full.)/&* (Pink Scarf and Pink's Staff will wait at the flower shop.)/%"");
        }
        else if (pink_scarf_pending)
        {
            c_msgset(0, ""* (Your WEAPON storage is full.)/&* (Pink Scarf will wait at the flower shop.)/%"");
        }
        else
        {
            c_msgset(0, ""* (Your WEAPON storage is full.)/&* (Pink's Staff will wait at the flower shop.)/%"");
        }
        c_talk_wait();
    }
    c_var_lerp_to_instance(pk_actor, ""image_index"", 4, 6);
", "ch5/gml_Object_obj_dw_pink_encounter_Step_0 reward message"),
});

PatchCode("gml_Object_obj_dw_fcastle_pinkshop_Create_0", new[]
{
    (@"roomphase = 0;
charinit = 0;
scr_musicer(""flowery_iog_extended.ogg"");
", @"roomphase = 0;
charinit = 0;
if (!variable_global_exists(""secret_boss_challenge""))
{
    ossafe_ini_open(""true_config.ini"");
    global.secret_boss_challenge = ini_read_real(""MODS"", ""SECRET_BOSS_CHALLENGE"", 0);
    ossafe_ini_close();
}
regularpurchasegoal = 3;
totalpurchasegoal = 4;
// Preserve flower-shop progression for saves that already used v0.3.0's
// unconditional fourth purchase before updating.
var legacyregularpurchases = 0;
for (var sbc_flower_i = 0; sbc_flower_i < 6; sbc_flower_i += 1)
{
    legacyregularpurchases += scr_flag_get_ext(1860, sbc_flower_i);
}
if (legacyregularpurchases >= 4)
{
    regularpurchasegoal = 4;
    totalpurchasegoal = 5;
}
if (global.flag[1815] == 1)
{
    // Old completed clears with no proof of a challenge clear remain ineligible
    // instead of becoming eligible merely because Boss Challenge was enabled later.
    if (global.flag[2493] == 0)
    {
        if (global.flag[2492] == 1 || global.flag[2492] == 2)
        {
            global.flag[2493] = 1;
        }
        else
        {
            global.flag[2493] = 2;
        }
    }
    if (global.flag[2493] == 1)
    {
        regularpurchasegoal = 4;
        totalpurchasegoal = 5;
        if (global.flag[2491] == 0)
        {
            global.flag[1312] += 3;
            global.flag[2491] = 1;
        }
        if (global.flag[2490] == 0)
        {
            if (scr_weaponcheck_inventory(38) > 0 || scr_weaponcheck_equipped_any(38) > 0)
            {
                global.flag[2490] = 1;
            }
            else
            {
                scr_weaponget(38);
                if (noroom == 0)
                {
                    global.flag[2490] = 1;
                }
            }
        }
    }
    if (global.flag[2492] == 0)
    {
        global.flag[2492] = 3;
    }
    if (global.flag[2492] == 2)
    {
        if (scr_weaponcheck_inventory(39) > 0 || scr_weaponcheck_equipped_any(39) > 0)
        {
            global.flag[2492] = 1;
        }
        else
        {
            scr_weaponget(39);
            if (noroom == 0)
            {
                global.flag[2492] = 1;
            }
        }
    }
}
scr_musicer(""flowery_iog_extended.ogg"");
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Create_0 retroactive reward"),
    (@"    if (purchasecount == 4)
    {
        with (flower[6])
", @"    if (purchasecount == totalpurchasegoal)
    {
        with (flower[6])
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Create_0 completed purchase count"),
});

PatchCode("gml_Object_obj_dw_fcastle_pinkshop_Other_11", new[]
{
    (@"    c_msgnextsubloc(""~1* Now^1, choose 3 of us!/%"", (global.lang == ""ja"") ? ""\\m5\t\t\t"" : ""\\m5\t\t"", (global.lang == ""ja"") ? ""&\t\t\t\t"" : ""&\t\t"", ""obj_dw_fcastle_pinkshop_slash_Other_11_gml_85_0"");
", @"    if (regularpurchasegoal == 4)
    {
        c_msgnextsubloc(""~1* Now^1, choose 4 of us!/%"", (global.lang == ""ja"") ? ""\\m5			"" : ""\\m5		"", (global.lang == ""ja"") ? ""&				"" : ""&		"", ""obj_dw_fcastle_pinkshop_slash_Other_11_gml_85_0"");
    }
    else
    {
        c_msgnextsubloc(""~1* Now^1, choose 3 of us!/%"", (global.lang == ""ja"") ? ""\\m5			"" : ""\\m5		"", (global.lang == ""ja"") ? ""&				"" : ""&		"", ""obj_dw_fcastle_pinkshop_slash_Other_11_gml_85_0"");
    }
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Other_11 choice count dialogue"),
});

PatchCode("gml_Object_obj_dw_fcastle_pinkshop_Step_0", new[]
{
    (@"    if (purchasecount == 3)
    {
        fcost = 1;
        pcost = 0;
    }
", @"    if (purchasecount == regularpurchasegoal)
    {
        fcost = 1;
        pcost = 0;
    }
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Step_0 Flowery price threshold"),
    (@"    if (purchasecount == 4)
    {
        with (flower[6])
", @"    if (purchasecount == totalpurchasegoal)
    {
        with (flower[6])
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Step_0 final podium removal threshold"),
    (@"        if (purchasecount == 3)
        {
            global.interact = 1;
            timer = 0;
            con = 45;
        }
        else if (purchasecount == 4)
        {
", @"        if (purchasecount == regularpurchasegoal)
        {
            global.interact = 1;
            timer = 0;
            con = 45;
        }
        else if (purchasecount == totalpurchasegoal)
        {
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Step_0 progression thresholds"),
});

importGroup.Import();
