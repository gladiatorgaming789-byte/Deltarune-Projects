Secret Boss Challenge v0.2.0

Install this ZIP directly through Deltamod. Keep the archive intact.
The package ID is unchanged, so v0.2.0 updates the existing Secret Boss Challenge installation.

CHAPTERS 1 AND 2
- Keeps the existing optional Boss Challenge setting and dual secret-boss rewards.

CHAPTER 5: PINK REWARD UPDATE
- Defeating Pink awards Pink's Staff, a Ralsei weapon.
- Pink's Staff stats: 8 AT, 4 DF, 12 MAG.
- Defeating Pink awards 3 additional Pink Coins once per save.
- The flower shop permits four regular flower purchases instead of three.
- Flowery's special scarf remains available afterward as the fifth purchase.

EXISTING SAVES AND FULL INVENTORIES
- Saves that defeated Pink before installing v0.2.0 receive the new reward when entering the flower shop.
- If WEAPON storage is full, Pink's Staff remains pending and the flower shop retries the grant later.
- The extra Pink Coins are protected by a one-time save flag and cannot be duplicated by reinstalling or reapplying the patch.

COMPATIBILITY
- Uses source-anchor CSX patches for Deltamod merge support.
- Tested with Debug Mode v4.01 in both patch orders for Chapter 5.
- A mod that changes the exact same Pink reward, weapon table, or flower-shop anchors may require a dedicated merged version.

Target: DELTARUNE Windows full release, launcher version v23.
