using System;
using UndertaleModLib.Models;
using UndertaleModLib.Compiler;

EnsureDataLoaded();

UndertaleModLib.Compiler.CodeImportGroup importGroup = new(Data, null, Data.ToolInfo.DecompilerSettings)
{
    ThrowOnNoOpFindReplace = true,
    MainThreadAction = MainThreadAction
};

int CountOccurrences(string source, string value)
{
    if (String.IsNullOrEmpty(value))
        return 0;
    int count = 0;
    int index = 0;
    while ((index = source.IndexOf(value, index, StringComparison.Ordinal)) >= 0)
    {
        count++;
        index += value.Length;
    }
    return count;
}

string ReplaceExact(string source, string oldText, string newText, string label)
{
    int oldCount = CountOccurrences(source, oldText);
    if (oldCount == 1)
        return source.Replace(oldText, newText, StringComparison.Ordinal);

    // Permit a second run without duplicating the patch.
    if (oldCount == 0 && CountOccurrences(source, newText) == 1)
        return source;

    throw new Exception($"Secret Boss Challenge: {label} expected one source match, found {oldCount}. The game version or another mod changed the same code.");
}

void PatchCode(string codeName, (string OldText, string NewText, string Label)[] replacements)
{
    UndertaleCode code = Data.Code.ByName(codeName);
    if (code is null)
        throw new Exception($"Secret Boss Challenge: missing code entry {codeName}.");

    string source = GetDecompiledText(code);
    string patched = source;
    foreach (var replacement in replacements)
        patched = ReplaceExact(patched, replacement.OldText, replacement.NewText, replacement.Label);

    if (!String.Equals(source, patched, StringComparison.Ordinal))
        importGroup.QueueReplace(code, patched);
}

if (Data.Code.ByName("gml_Object_obj_pink_enemy_Create_0") is null)
    throw new Exception("Secret Boss Challenge: this patch targets DELTARUNE Chapter 5.");

// Weapon ID 38 is unused in the supplied Chapter 5 build. Armor IDs use a separate namespace.
PatchCode("gml_GlobalScript_scr_weaponinfo", new[]
{
    (@"            weaponabilitytemp = """";
            value = 1000;
            break;
        case 50:
            weaponnametemp = stringsetloc(""JingleBlade"", ""scr_weaponinfo_slash_scr_weaponinfo_gml_629_0"");
", @"            weaponabilitytemp = """";
            value = 1000;
            break;
        case 38:
            weaponnametemp = stringsetloc(""Pink's Staff"", ""secret_boss_challenge_pinks_staff_name"");
            weapondesctemp = stringsetloc(""A heart-topped staff left by Pink.#It glows with bold, affectionate magic."", ""secret_boss_challenge_pinks_staff_desc"");
            wmessage2temp = stringsetloc(""Way too pink. Even for me."", ""secret_boss_challenge_pinks_staff_susie"");
            wmessage3temp = stringsetloc(""It feels warm... and a little dramatic!"", ""secret_boss_challenge_pinks_staff_ralsei"");
            wmessage4temp = stringsetloc(""It's adorable!"", ""secret_boss_challenge_pinks_staff_noelle"");
            weaponattemp = 8;
            weapondftemp = 4;
            weaponmagtemp = 12;
            weaponboltstemp = 1;
            weaponstyletemp = ""?"";
            weapongrazeamttemp = 0;
            weapongrazesizetemp = 0;
            weaponchar1temp = 0;
            weaponchar2temp = 0;
            weaponchar3temp = 1;
            weaponchar4temp = 0;
            weaponicontemp = 3;
            weaponabilityicontemp = 0;
            weaponabilitytemp = """";
            value = 1500;
            break;
        case 50:
            weaponnametemp = stringsetloc(""JingleBlade"", ""scr_weaponinfo_slash_scr_weaponinfo_gml_629_0"");
", "ch5/gml_GlobalScript_scr_weaponinfo Pink's Staff definition"),
});

PatchCode("gml_Object_obj_dw_pink_encounter_Step_0", new[]
{
    (@"if (con == 5)
{
    con = 6;
    pinkface.silhouette = false;
", @"if (con == 5)
{
    con = 6;
    var pink_staff_awarded_now = false;
    var pink_staff_pending = false;
    var pink_coins_awarded_now = false;
    if (global.flag[2490] == 0)
    {
        if (scr_weaponcheck_inventory(38) > 0 || scr_weaponcheck_equipped_any(38) > 0)
        {
            global.flag[2490] = 1;
        }
        else
        {
            scr_weaponget(38);
            if (noroom == 0)
            {
                global.flag[2490] = 1;
                pink_staff_awarded_now = true;
            }
            else
            {
                pink_staff_pending = true;
            }
        }
    }
    if (global.flag[2491] == 0)
    {
        global.flag[1312] += 3;
        global.flag[2491] = 1;
        pink_coins_awarded_now = true;
    }
    pinkface.silhouette = false;
", "ch5/gml_Object_obj_dw_pink_encounter_Step_0 reward state"),
    (@"    c_snd_play(snd_sparkle_glock);
    c_speaker(""no_name"");
    c_msgsetloc(0, ""* (SHADOWCRYSTAL was added to your KEY ITEMS.)/%"", ""obj_dw_pink_encounter_slash_Step_0_gml_1200_0"");
    c_talk_wait();
    c_var_lerp_to_instance(pk_actor, ""image_index"", 4, 6);
", @"    c_snd_play(snd_sparkle_glock);
    c_speaker(""no_name"");
    c_msgsetloc(0, ""* (SHADOWCRYSTAL was added to your KEY ITEMS.)/%"", ""obj_dw_pink_encounter_slash_Step_0_gml_1200_0"");
    c_talk_wait();
    if (pink_staff_awarded_now && pink_coins_awarded_now)
    {
        c_snd_play(snd_item);
        c_speaker(""no_name"");
        c_msgset(0, ""* (You got Pink's Staff.)/&* (You got 3 Pink Coins.)/%"");
        c_talk_wait();
    }
    else if (pink_staff_awarded_now)
    {
        c_snd_play(snd_item);
        c_speaker(""no_name"");
        c_msgset(0, ""* (You got Pink's Staff.)/%"");
        c_talk_wait();
    }
    else if (pink_coins_awarded_now)
    {
        c_snd_play(snd_pink_coin);
        c_speaker(""no_name"");
        c_msgset(0, ""* (You got 3 Pink Coins.)/%"");
        c_talk_wait();
    }
    if (pink_staff_pending)
    {
        c_speaker(""no_name"");
        c_msgset(0, ""* (Your WEAPON storage is full.)/&* (Pink's Staff will be waiting at the flower shop.)/%"");
        c_talk_wait();
    }
    c_var_lerp_to_instance(pk_actor, ""image_index"", 4, 6);
", "ch5/gml_Object_obj_dw_pink_encounter_Step_0 reward message"),
});

PatchCode("gml_Object_obj_dw_fcastle_pinkshop_Create_0", new[]
{
    (@"roomphase = 0;
charinit = 0;
scr_musicer(""flowery_iog_extended.ogg"");
", @"roomphase = 0;
charinit = 0;
if (global.flag[1815] == 1)
{
    if (global.flag[2491] == 0)
    {
        global.flag[1312] += 3;
        global.flag[2491] = 1;
    }
    if (global.flag[2490] == 0)
    {
        if (scr_weaponcheck_inventory(38) > 0 || scr_weaponcheck_equipped_any(38) > 0)
        {
            global.flag[2490] = 1;
        }
        else
        {
            scr_weaponget(38);
            if (noroom == 0)
            {
                global.flag[2490] = 1;
            }
        }
    }
}
scr_musicer(""flowery_iog_extended.ogg"");
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Create_0 retroactive reward"),
    (@"    if (purchasecount == 4)
    {
        with (flower[6])
", @"    if (purchasecount == 5)
    {
        with (flower[6])
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Create_0 completed purchase count"),
});

PatchCode("gml_Object_obj_dw_fcastle_pinkshop_Other_11", new[]
{
    (@"    c_msgnextsubloc(""~1* Now^1, choose 3 of us!/%"", (global.lang == ""ja"") ? ""\\m5\t\t\t"" : ""\\m5\t\t"", (global.lang == ""ja"") ? ""&\t\t\t\t"" : ""&\t\t"", ""obj_dw_fcastle_pinkshop_slash_Other_11_gml_85_0"");
", @"    c_msgnextsubloc(""~1* Now^1, choose 4 of us!/%"", (global.lang == ""ja"") ? ""\\m5\t\t\t"" : ""\\m5\t\t"", (global.lang == ""ja"") ? ""&\t\t\t\t"" : ""&\t\t"", ""obj_dw_fcastle_pinkshop_slash_Other_11_gml_85_0"");
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Other_11 choice count dialogue"),
});

PatchCode("gml_Object_obj_dw_fcastle_pinkshop_Step_0", new[]
{
    (@"    if (purchasecount == 3)
    {
        fcost = 1;
        pcost = 0;
    }
", @"    if (purchasecount == 4)
    {
        fcost = 1;
        pcost = 0;
    }
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Step_0 Flowery price threshold"),
    (@"    if (purchasecount == 4)
    {
        with (flower[6])
", @"    if (purchasecount == 5)
    {
        with (flower[6])
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Step_0 final podium removal threshold"),
    (@"        if (purchasecount == 3)
        {
            global.interact = 1;
            timer = 0;
            con = 45;
        }
        else if (purchasecount == 4)
        {
", @"        if (purchasecount == 4)
        {
            global.interact = 1;
            timer = 0;
            con = 45;
        }
        else if (purchasecount == 5)
        {
", "ch5/gml_Object_obj_dw_fcastle_pinkshop_Step_0 progression thresholds"),
});

importGroup.Import();
