Secret Boss Challenge v0.3.0

Install this ZIP directly through Deltamod. Keep the archive intact.
The package ID is unchanged, so v0.3.0 updates the existing Secret Boss Challenge installation.

CHAPTERS 1 AND 2
- Keeps the optional Boss Challenge setting, harder secret bosses, and dual secret-boss rewards.

CHAPTER 5: PINK REWARD UPDATE
- Boss Challenge can now be toggled from Chapter 5's CONFIG menu.
- Defeating Pink always awards Pink Scarf, a Ralsei weapon.
- Pink Scarf stats: 8 AT, 4 DF, 12 MAG.
- Defeating Pink awards 3 additional Pink Coins once per save.
- Defeating Pink with Meaner Bombs selected AND Boss Challenge ON awards Pink's Staff.
- Pink's Staff is a Kris weapon with 14 AT, 2 DF, and 4 MAG.
- Staff eligibility is recorded when Pink is defeated; enabling Boss Challenge afterward does not qualify a new clear.
- The flower shop permits four regular flower purchases instead of three.
- Flowery's special scarf remains available afterward as the fifth purchase.

V0.2.0 SAVE MIGRATION
- Weapon ID 38 now becomes Pink Scarf, so an existing v0.2.0 Pink's Staff automatically converts without being lost.
- Eligible v0.2.0 saves can receive the new Kris-only Pink's Staff from the flower shop.
- If WEAPON storage is full, either reward remains pending and the flower shop retries later.
- All coin and equipment grants use one-time save states.

COMPATIBILITY
- Uses source-anchor CSX patches for Deltamod merge support.
- Chapter 5 was tested with Debug Mode v4.01 in both patch orders.
- Applying the Chapter 5 script twice produces a byte-identical data.win.
- A mod changing the same CONFIG, Pink reward, weapon table, or flower-shop anchors may require a dedicated merged version.

Target: DELTARUNE Windows full release, launcher version v23.
